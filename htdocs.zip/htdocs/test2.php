<!DOCTYPE html>
<html>
<head>
    <title>BMI Calculation Page</title>
    <style>
        /* CSS styles for the page */
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 20px;
        }
        
        h1 {
            text-align: center;
            color: #333333;
        }
        
        .container {
            max-width: 500px;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }
        
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: #333333;
        }
        
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #cccccc;
            border-radius: 4px;
        }
        
        input[type="submit"] {
            background-color: #4caf50;
            color: #ffffff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        
        .result {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #cccccc;
            border-radius: 4px;
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>BMI Calculation Page</h1>
        <link rel="stylesheet" href="https://pyscript.net/latest/pyscript.css" />
    <script defer src="https://pyscript.net/latest/pyscript.js"></script>
    <link rel=”stylesheet” href = “path/to/pyscript.css”/>
<script defer src =”path/to/pyscript.js”></script>
        <py-script>
            
        print("hello world")
        
    </py-script>

        <?php
        // Retrieve data from the CSV file or from the previous page
        // and perform the necessary BMI calculation logic
        
        // Check if the form is submitted and the required fields are filled
        if ($_SERVER["REQUEST_METHOD"]=="POST" ) {
            // Retrieve the input values
            $weight = $_POST["weight"];
            $height = $_POST["height"];
			$Nameid = $_POST["userid"];
            // Calculate BMI
            $bmi = $weight / (($height / 100) ** 2);
            
            // Determine the BMI category
            $category = "";
            if ($bmi < 18.5) {
                $category = "Underweight";
            } elseif ($bmi >= 18.5 && $bmi < 25) {
                $category = "Normal weight";
            } elseif ($bmi >= 25 && $bmi < 30) {
                $category = "Overweight";
            } elseif ($bmi >= 30) {
                $category = "Obese";
            }
            
            // Display the result
			echo '<p>Hi there!</p>';
			echo '<p><strong>Id: </strong>'.$Nameid.'</p>';
			
            echo '<p><strong>BMI:</strong> ' . number_format($bmi, 2) . '</p>';
            echo '<p><strong>Category:</strong> ' . $category . '</p>';
            
            
		}
		
        ?>
        
        <form action="page1.php" method="get">
            <input type="submit" value="Go back to Input Page">
        </form>
    </div>
</body>
</html>