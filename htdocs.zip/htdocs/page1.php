<!DOCTYPE html>
<html>
<head>
  <title>Calorie Tracker - Input Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
	  background-image: url("image.jpg");
      background-size: 100% 100%;
      margin: 0;
      padding: 20px;
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    .container {
      max-width: 500px;
      margin: 0 auto;
      background-color: #fff;
      padding: 30px;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      font-weight: bold;
      display: block;
      margin-bottom: 5px;
    }

    .form-group input[type="text"],
    .form-group input[type="number"] {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    .form-group input[type="submit"] {
      background-color: #4CAF50;
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 4px;
      cursor: pointer;
    }

    .form-group input[type="submit"]:hover {
      background-color: #45a049;
    }
  </style>
</head>
<body>
  <form method = "post" action = "test2.php">
  <h1>Calorie Tracker - Input Page</h1>
  <div class="container">
    <form action="store_data.php" method="POST">
      <div class="form-group">
        <label for="userid">User ID:</label>
        <input type="text" id="userid" name="userid" required>
      </div>

      <div class="form-group">
        <label for="age">Age:</label>
        <input type="number" id="age" name="age" required>
      </div>

      <div class="form-group">
        <label for="gender">Gender:</label>
        <select id="gender" name="gender" required>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
      </div>

      <div class="form-group">
        <label for="height">Height (cm):</label>
        <input type="number" id="height" name="height" required>
      </div>

      <div class="form-group">
        <label for="weight">Weight (kg):</label>
        <input type="number" id="weight" name="weight" required>
      </div>

      <div class="form-group">
        <label for="duration">Duration (minutes):</label>
        <input type="number" id="duration" name="duration" required>
      </div>

      <div class="form-group">
        <label for="heartrate">Heart Rate:</label>
        <input type="number" id="heartrate" name="heartrate" required>
      </div>

      <div class="form-group">
        <label for="temperature">Body Temperature (°C):</label>
        <input type="number" id="temperature" name="temperature" required>
      </div>

      <div class="form-group">
        <label for="calories">Calories:</label>
        <input type="number" id="calories" name="calories" required>
      </div>

      <div class="form-group">
        <input type="submit" value="Submit">
      </div>
    </form>
  </div>
</body>
</html>
