import http.server
import socketserver
import csv

# Create a request handler class
class MyRequestHandler(http.server.SimpleHTTPRequestHandler):
    def do_POST(self):
        # Retrieve form data
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length).decode('utf-8')
        form_data = {}
        for item in post_data.split('&'):
            key, value = item.split('=')
            form_data[key] = value

        # Write input to CSV file
        with open('calorie.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([form_data.get('userid', ''),
                             form_data.get('age', ''),
                             form_data.get('gender', ''),
                             form_data.get('height', ''),
                             form_data.get('weight', ''),
                             form_data.get('duration', ''),
                             form_data.get('heartrate', ''),
                             form_data.get('temperature', ''),
                             form_data.get('calories', '')])

        # Send response
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(b'Data written to CSV file successfully!')

# Set up the server
port = 8000
handler = MyRequestHandler
httpd = socketserver.TCPServer(('localhost', port), handler)

# Start the server
print(f'Server running on http://localhost:{port}')
httpd.serve_forever()
