<!doctype html>
<html lang = "en">
	<head>
		<title>Login Credentials</title>
		<meta charset = "utf-8">
		<link href = "style1.css" rel = "stylesheet">
	</head>
	<body>
		<form action = "<?php echo $_SERVER["PHP_SELF"]; ?>" method = "post">
		<h1>Login Credentials</h1>
		<fieldset>
		Username: <input type = "text" name = "usercred" id = "user" placeholder = "Enter username" /><br><br>
		Password: <input type = "text" name = "pwdcred" id = "pwd" placeholder = "Enter Password"/>
		</fieldset>
		<br><br><br><button type = "submit" name = "submit">Submit</button><br><br>
		</form>
		<?php
		if ($_SERVER["REQUEST_METHOD"]=="POST"){
			$un = $_POST["usercred"];
			$pwd = $_POST["pwdcred"];
			if($un==""){
				echo "Enter appropriate USERNAME";
			}
			elseif($pwd==""){
				echo "Enter appropriate PASSWORD";
			}
			elseif($un!="" and $pwd!=""){
				echo "Welcome ".$un." !!";
			}
		}
		?>
	
	</body>
</html>