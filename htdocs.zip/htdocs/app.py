from flask import Flask, render_template, request
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb
from sklearn.metrics import mean_absolute_error as mae
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn import metrics
from sklearn.svm import SVC
from xgboost import XGBRegressor
from sklearn.linear_model import LinearRegression, Lasso, Ridge
from sklearn.ensemble import RandomForestRegressor
  
import warnings
warnings.filterwarnings('ignore')

app = Flask(__name__)

# Define the route for the input page
@app.route('/')
def input_page():
    return render_template('page1.php')

# Define the route for processing the form submission
@app.route('/process_form', methods=['POST'])
def process_form():
    # Retrieve the form data
    userid = request.form['userid']
    gender = request.form['gender']
    age = int(request.form['age'])
    height = float(request.form['height'])
    weight = float(request.form['weight'])
    duration = int(request.form['duration'])
    heartrate = int(request.form['heartrate'])
    temperature = float(request.form['temperature'])
    calories = float(request.form['calories'])

    # Perform the necessary calculations or data processing
    # You can integrate your machine learning model or any other calculations here
    print("Hello")
    
    # Return a response or render a template with the processed data
    return render_template('output_page.php', userid=userid, gender=gender, age=age, height=height, weight=weight, duration=duration, heartrate=heartrate, temperature=temperature, calories=calories)

if __name__ == '__main__':
    app.run(debug=True)

