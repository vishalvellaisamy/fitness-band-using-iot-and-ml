import asyncio
        import pyodide
import pyodide_js
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb

from sklearn.metrics import mean_absolute_error as mae
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn import metrics
from sklearn.svm import SVC
from xgboost import XGBRegressor
from sklearn.linear_model import LinearRegression, Lasso, Ridge
from sklearn.ensemble import RandomForestRegressor
print("Hello world")
async def load_package_and_execute():
    

    await pyodide_js.loadPackage('numpy')
    await pyodide_js.loadPackage('pandas')
    await pyodide_js.loadPackage('matplotlib.pyplot')
    await pyodide_js.loadPackage('seaborn')
    await pyodide_js.loadPackage('scikit-learn')
    await pyodide_js.loadPackage('xgboost')


  
import warnings
warnings.filterwarnings('ignore')



df = pd.read_csv('C:/xampp/htdocs/calorie.csv')
df.head()
print(df.shape)
print(df.info())
print(df.describe())
print('Hello world')
loop = asyncio.get_event_loop()
task = loop.create_task(load_package_and_execute())

loop.run_until_complete(task)

