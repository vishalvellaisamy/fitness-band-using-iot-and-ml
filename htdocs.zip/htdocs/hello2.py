from flask import Flask, render_template, request

app = Flask(__name__)

# Define the route for the input page
@app.route('/')
def input_page():
    return render_template('page1.php')

# Define the route for processing the form submission
@app.route('/process_form', methods=['POST'])
def process_form():
    # Retrieve the form data
    userid = request.form['userid']
    gender = request.form['gender']
    age = int(request.form['age'])
    height = float(request.form['height'])
    weight = float(request.form['weight'])
    duration = int(request.form['duration'])
    heartrate = int(request.form['heartrate'])
    temperature = float(request.form['temperature'])
    calories = float(request.form['calories'])

    # Perform the necessary calculations or data processing
    # You can integrate your machine learning model or any other calculations here

    # Return a response or render a template with the processed data
    return f"User ID: {userid}<br>Gender: {gender}<br>Age: {age}<br>Height: {height}<br>Weight: {weight}<br>Duration: {duration}<br>Heart Rate: {heartrate}<br>Temperature: {temperature}<br>Calories: {calories}"

if __name__ == '__main__':
    app.run(debug=True)
